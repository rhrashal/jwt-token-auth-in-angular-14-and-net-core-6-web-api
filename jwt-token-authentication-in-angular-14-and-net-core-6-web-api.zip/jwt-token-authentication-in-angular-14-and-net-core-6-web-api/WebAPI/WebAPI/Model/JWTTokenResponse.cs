﻿namespace WebAPI.Model
{
    public class JWTTokenResponse
    {
        public string? Token { get; set; }
    }
}
