export class Products {
    productId: any;
    productName?: string;
    productCost?: number;
    productDescription?: string;
    productStock?: number;
  }